<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# Navigator

MODX 3 port of Navigator snippet by PMS.',
    'requires' => 
    array (
      'modx' => '>=3.0.0-alpha',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'e7e60087cb8f911bb01265452730f6af',
      'native_key' => 'navigator',
      'filename' => 'MODX/Revolution/modNamespace/7dfadf4060eece4d2c1beac6acb938cf.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'd81ecd57043b550f2c4c48808307745e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/d380cde103f4d906f02a723c0179e74c.vehicle',
    ),
  ),
);