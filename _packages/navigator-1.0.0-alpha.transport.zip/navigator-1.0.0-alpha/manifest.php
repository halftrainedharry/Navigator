<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# Navigator

MODX 3 port of Navigator snippet by PMS.',
    'requires' => 
    array (
      'modx' => '>=3.0.0-alpha',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '3ce0740ebe024edf4f82ce8ca66a221a',
      'native_key' => 'navigator',
      'filename' => 'MODX/Revolution/modNamespace/58f78cfcf4a1f683c99da15ba1630596.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'dcd68d4a7d0f1188bdc693c56fd2e119',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/9074f4decdf6b6416c1edc2d09f6980b.vehicle',
    ),
  ),
);